"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var customer_1 = require("../exercise-3/customer");
var customer = new customer_1.Customer("John", "Smith", 50);
customer.greeter();
customer.getAge();
