
import {Customer} from "../exercise-3/customer"

let customer = new Customer("John", "Smith", 50)
customer.greeter();
customer.getAge()

