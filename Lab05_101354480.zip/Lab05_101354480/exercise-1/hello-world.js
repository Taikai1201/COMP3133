// var greeter = function (name){
//     console.log('Hello ' + name);
// }
var greeter = function (firstName, lastName) {
    console.log("Hello ".concat(firstName, " ").concat(lastName));
};
greeter("John", "Smith");
