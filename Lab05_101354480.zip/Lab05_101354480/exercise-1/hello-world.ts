// var greeter = function (name){
//     console.log('Hello ' + name);
// }

let greeter = (firstName, lastName) => {
    console.log(`Hello ${firstName} ${lastName}`);
}


greeter("John", "Smith")